const radioUncheckedMock = [
  { checked: false },
  { checked: false },
  { checked: false },
];

const radioCheckedMock = [
  { checked: true },
  { checked: true },
  { checked: true },
];
